/**
 * 
 */
package medical6.m2i.fr;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Properties;

/**
 * @author тс
 *
 */
public class Patient {

	public String nom;
	public String prenom;
	public Date date;
	public String adresse;
	public String pays;
	public String ville;
	private Properties config;

	/**
	 * @param nom
	 * @param prenom
	 * @param date
	 * @param adress
	 * @param pays
	 * @param ville
	 */
	public Patient(String nom, String prenom, Date date, String adresse, String pays, String ville) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.date = date;
		this.adresse = adresse;
		this.pays = pays;
		this.ville = ville;

		config = new Properties();
		try {
			config.load(getClass().getResourceAsStream("patients.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}

	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the adress
	 */
	public String getAdress() {
		return adresse;
	}

	/**
	 * @param adress the adress to set
	 */
	public void setAdress(String adresse) {
		this.adresse = adresse;
	}

	/**
	 * @return the pays
	 */
	public String getPays() {
		return pays;
	}

	/**
	 * @param pays the pays to set
	 */
	public void setPays(String pays) {
		this.pays = pays;
	}

	/**
	 * @return the ville
	 */
	public String getVille() {
		return ville;
	}

	/**
	 * @param ville the ville to set
	 */
	public void setVille(String ville) {
		this.ville = ville;
	}

	public void savePatient() throws ClassNotFoundException, SQLException {
		String url = config.getProperty("url");
		String user = config.getProperty("user");
		String password = config.getProperty("password");
		String sql = null;

		// Get Connection Driver to establish database connection
		Class.forName("com.mysql.cj.jdbc.Driver");
		// Establish connection
		Connection connection = DriverManager.getConnection(url, user, password);

		// creation du statement , Write SQL query to insert data
		Statement statement = connection.createStatement();
		PreparedStatement psPatients = connection.prepareStatement(
				"INSERT INTO Patients ( nom, prenom,dateNaissance,adresse, pays, ville) VALUES(?,?,?,?,?,?)");

		psPatients.setString(1, nom);
		psPatients.setString(2, prenom);
		psPatients.setDate(3, date);
		psPatients.setString(4, adresse);
		psPatients.setString(5, pays);
		psPatients.setString(6, ville);
		int i = psPatients.executeUpdate();
		if (i != 0) {
			System.out.println("<br>Record has been inserted");
		} else {
			System.out.println("failed to insert the data");
		}

	}

	public void loadDB() throws ClassNotFoundException, SQLException {
		
		String url = config.getProperty("url");
		String user = config.getProperty("user");
		String password = config.getProperty("password");
		String sql = null;

	      //Get Connection Driver to establish database connection
	      Class.forName("com.mysql.cj.jdbc.Driver");
	  //Establish connection
	      Connection connection = DriverManager.getConnection(url, user, password);
	      
	   // creation du statement , Write SQL query to insert data
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery("select * from patients");
			while (result.next()) 
            {  
				String prenom = result.getString("prenom");
				String nom = result.getString("nom");
				String datenaissance = result.getString("datenaissance");
				String adresse = result.getString("adresse");
				String pays =result.getString("pays");
				String ville = result.getString("ville");   
                System.out.println("<tr><td>" + prenom + "</td><td>" + nom + "</td><td>" + datenaissance
                		+ "</td><td>" + adresse + "</td><td>" + pays + "</td><td>" + ville + "</td></tr>");   
            }  
			System.out.println("</table>");  
			System.out.println("</html></body>");
			
			 //validation de la transaction
			 connection.commit();
	}
}
